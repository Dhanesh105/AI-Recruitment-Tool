// This is a temporary workaround to run the server without TypeScript compilation
require('ts-node/register');
require('./src/server.ts');
