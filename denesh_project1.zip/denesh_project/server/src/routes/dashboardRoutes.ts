import express from 'express';
import { getDashboardMetrics } from '../controllers/dashboardController';
import { protect, authorize } from '../middleware/auth';

const router = express.Router();

// Protect all routes
router.use(protect);

// Get dashboard metrics (recruiter only)
router.get('/metrics', authorize('recruiter', 'admin'), (req, res, next) => {
  getDashboardMetrics(req, res).catch(next);
});

export default router;
