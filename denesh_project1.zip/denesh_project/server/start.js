// Bootstrap file to run server with TypeScript without compilation errors
require('ts-node/register/transpile-only');
require('./src/server.ts');
